﻿namespace PhotoShare.Services
{
    public class TownService
    {
       
    }
}
