﻿namespace PhotoShare.Client.Core.Dtos
{
    public class AlbumDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
