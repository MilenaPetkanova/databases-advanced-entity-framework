﻿namespace PhotoShare.Client.Core.Dtos
{
    public class FriendDto
    {
        public string Username { get; set; }
    }
}
