﻿namespace PhotoShare.Client.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
